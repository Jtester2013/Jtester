/**
 * 
 */
/**
 * @author zzj
 *
 */
package plugin.ui.window.configuration.menu;