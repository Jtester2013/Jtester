package plugin.ui.window.configuration.util;

import org.eclipse.swt.widgets.Tree;

public class TreeConcrete {

	public TreeConcrete() {
		// TODO Auto-generated constructor stub
	}
	
	public static Tree treeConcrete(String xmlPath){
		Tree tree = null;
		
		return tree;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
