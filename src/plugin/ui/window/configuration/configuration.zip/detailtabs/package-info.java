/**
 * this package contains the tab composite of detail configuration
 */
/**
 * @author zzj
 *
 */
package plugin.ui.window.configuration.detailtabs;