/**
 * This package stores the configuration files of all the configuration item.
 */
/**
 * @author zzj
 *
 */
package plugin.ui.window.configuration.file;